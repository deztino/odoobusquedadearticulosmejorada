# -*- coding: utf-8 -*-
{
    'name': "Product - Sale",
    'summary': """Modificación de Product""",
    'description': """

    """,

    'author': "Daniel Mattos R.",
    'website': "http://www.py-devs.com",

    'category': 'Product',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['product'],

    # always loaded
    'data': [
        #'data/mrp_productionnote_data.xml',
        #'data/product_data.xml',
        #'views/mrp_productionnote_views.xml',
        #'views/mrp_workorder_views.xml',
        # 'security/security.xml',
        # 'security/ir.model.access.csv',
        # 'views/calendar_views.xml',
        'views.xml',
        # 'templates.xml',
    ],
}